<?php
/**
 * @copyright 2019 Paylike.com.
 * @author Panos <panos@Paylike.com>
 * Date: 17/9/2019
 * Time: 11:17 πμ
 */

fn_register_hooks(
    'change_order_status'
);