<?php
/**
 * @copyright 2019 Paylike.io.
 * @author Panos <support@cs-cart.sg>
 * Date: 17/9/2019
 * Time: 11:17 πμ
 */

fn_register_hooks(
    'change_order_status'
);